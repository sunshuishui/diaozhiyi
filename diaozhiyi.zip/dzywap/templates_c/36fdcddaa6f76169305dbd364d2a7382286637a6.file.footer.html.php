<?php /* Smarty version Smarty-3.1.18, created on 2015-02-03 03:35:58
         compiled from ".\templates\footer.html" */ ?>
<?php /*%%SmartyHeaderCode:2812154cef3eeb8e857-12394094%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '36fdcddaa6f76169305dbd364d2a7382286637a6' => 
    array (
      0 => '.\\templates\\footer.html',
      1 => 1422934555,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2812154cef3eeb8e857-12394094',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_54cef3eeb941a0_15937733',
  'variables' => 
  array (
    'domain' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54cef3eeb941a0_15937733')) {function content_54cef3eeb941a0_15937733($_smarty_tpl) {?><div id="bottom">
	<table cellpadding="0" cellspacing="0">
		<tr>
			<td><a href="<?php echo $_smarty_tpl->tpl_vars['domain']->value;?>
/dzywap/"><img src="images/bottom (1).png"  height="27"/><br />��ҳ</a></td>
			<td><a href="peixun.php"><img src="images/bottom (2).png"  height="27"/><br />��ѵ</a></td>
			<td><a href="#"><img src="images/bottom (3).png"  height="27"/><br />��ѯ</a></td>
			<td><a href="customer.php?type=3" class="bgnone"><img src="images/bottom (4).png"  height="27"/><br />��ϵ</a></td>
		</tr>
	</table>
</div><?php }} ?>
