<html>
<head>
<title>��������</title>
<meta http-equiv=Content-Type content=text/html; charset=gb2312>
</head>
<frameset rows="64,*"  frameborder="NO" border="0" framespacing="0">
	<frame src="<?=site_url('cadmin/admintop')?>" noresize="noresize" frameborder="NO" name="topFrame" scrolling="no" marginwidth="0" marginheight="0" target="main" />
  	<frameset cols="200,*"  rows="1000,*" id="frame">
	<frame src="<?=site_url('cadmin/left')?>" name="leftFrame" noresize="noresize" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" target="main" />
	<frame src="<?=site_url('ads/adsimg')?>" name="main" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" target="_self" />
<frame src="UntitledFrame-4"><frame src="UntitledFrame-5"></frameset>
</frameset>
<noframes>
  <body></body>
    </noframes>
</html>
